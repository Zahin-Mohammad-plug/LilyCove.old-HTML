export default function CardsPage() {
    return (
      <div className="min-h-screen flex items-center justify-center text-center">
        <h1 className="text-3xl font-bold">Cards Page</h1>
        <p>Coming Soon!</p>
      </div>
    );
  }
  